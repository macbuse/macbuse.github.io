import numpy as np
import numpy.random as npr
import matplotlib.pyplot as plt
import scipy.stats as stats
import math


## Exo 1 Polya
r=1
b=1
N=1000
plt.figure()
for i in range(0,5):
    urne=np.concatenate((np.ones(r),np.zeros(b)))
    X=np.zeros(N)
    for i in range(0,N):
        I=np.array([npr.choice(urne)])
        urne=np.concatenate((urne,I))
        X[i]=np.mean(urne)
    plt.plot(np.arange(1,N+1),X)
plt.title('Urne de Polya pour r= '+str(r) + ' et b= ' + str(b))
plt.show()
# Il semble bien que la proportion converge, mais vers une limite aléatoire
Nsim=1000
N=100
r=1
b=1
Y=np.zeros(Nsim)
for i in range(0,Nsim):
    urne=np.concatenate((np.ones(r),np.zeros(b)))
    for j in range(0,N):
        I=np.array([npr.choice(urne)])
        urne=np.concatenate((urne,I))
    Y[i]=np.mean(urne)
Ys=sorted(Y)
x=np.linspace(min(Y),max(Y),num=100)
plt.figure()
plt.step(Ys,np.arange(1,Nsim+1)/Nsim,color='r',where='post')
plt.plot(x,stats.beta(r,b).cdf(x))
plt.title('Convergence en loi de la proportion dans une urne de Polya\n  pour r= '+str(r) + ' et b= ' + str(b))
plt.show()

#
Nsim=1000
N=100
r=3
b=5
Y=np.zeros(Nsim)
for i in range(0,Nsim):
    urne=np.concatenate((np.ones(r),np.zeros(b)))
    for j in range(0,N):
        I=np.array([npr.choice(urne)])
        urne=np.concatenate((urne,I))
    Y[i]=np.mean(urne)
Ys=sorted(Y)
x=np.linspace(min(Y),max(Y),num=100)
plt.figure()
plt.step(Ys,np.arange(1,Nsim+1)/Nsim,color='r',where='post')
plt.plot(x,stats.beta(r,b).cdf(x))
plt.title('Convergence en loi de la proportion dans une urne de Polya\n pour r= '+str(r) + ' et b= ' + str(b))
plt.show()

## Exo 2
#q1
def WF(x0,n,N,Nsim):
    X=x0*np.ones((Nsim,n+1))
    for i in range(0,Nsim):
        for j in range(1,n+1):
            X[i,j]=npr.binomial(N,X[i,j-1]/N)
    return X


Nsim=20
N=5
x0=2
n=80
X=WF(x0,n,N,Nsim)
absc=np.arange(0,n+1)
plt.figure()
plt.plot(absc,X.T)
plt.title('Trajectoires pour N='+str(N))
plt.show()

N=10
x0=5
n=80
X=WF(x0,n,N,Nsim)
absc=np.arange(0,n+1)
plt.figure()
plt.plot(absc,X.T)
plt.title('Trajectoires pour N='+str(N))
plt.show()


N=30
x0=10
n=80
X=WF(x0,n,N,Nsim)
absc=np.arange(0,n+1)
plt.figure()
plt.plot(absc,X.T)
plt.title('Trajectoires pour N='+str(N))
plt.show()

# q2
Nsim=1000
N=10
def WFabs(x0,N,Nsim):
    XX=np.zeros(Nsim)
    for i in range(0,Nsim):
        X=x0
        while X!=0 and X!=N:
            X=npr.binomial(N,X/N)
        XX[i]=X==N
    return np.mean(XX)
p=np.zeros(N+1)
for x0 in np.arange(0,N+1):
        p[x0]=WFabs(x0,N,Nsim)
plt.figure()
absc=np.arange(0,N+1)
plt.plot(absc,p,label='estimation')
plt.plot(absc,p+1.96*np.sqrt(p*(1-p))/np.sqrt(Nsim),'--g')
plt.plot(absc,p-1.96*np.sqrt(p*(1-p))/np.sqrt(Nsim),'--g')
plt.plot(absc,absc/N,'r',label='theorique')
plt.xlabel('x0')
plt.title('Estimation de P_X0(X_T=N) pour N='+str(N)+' et Nsim='+str(Nsim))
plt.legend()
plt.show()

#q3

Nsim=1000
N=20
def WFtps(x0,N,Nsim):
    TT=np.zeros(Nsim)
    for i in range(0,Nsim):
        X=x0
        t=0
        while X!=0 and X!=N:
            X=npr.binomial(N,X/N)
            t=t+1
        TT[i]=t
    return [np.mean(TT),np.std(TT)]
tps=np.zeros(N+1)
s=np.zeros(N+1)
for x0 in np.arange(0,N+1):
    a=WFtps(x0,N,Nsim)
    tps[x0]=a[0]
    s[x0]=a[1]
plt.figure()
absc=np.arange(0,N+1)
plt.plot(absc,tps)
plt.plot(absc,tps+1.96*s/np.sqrt(Nsim),'--g')
plt.plot(absc,tps-1.96*s/np.sqrt(Nsim),'--g')
plt.xlabel('x0')
plt.title('Estimation de E_X0(T) pour N='+str(N)+' et Nsim='+str(Nsim))
plt.show()

## Exo 3 Wright-Fisher
# q1
P=np.array([[1,0,0,0,0,0],[1/4,1/2,1/4,0,0,0],[0,1/5,2/5,1/5,0,1/5],[0,0,0,1/6,1/3,1/2],[0,0,0,1/2,0,1/2],[0,0,0,1/4,0,3/4]])
print(P)
def exo3(x,n):
    X=[0 for j in range(n+1)]
    X[0]=x
    states=[j for j in range(6)]
    for i in range(1,n+1):
        X[i]=npr.choice(states,p=P[X[i-1],:])
    return X

#q2
Q=P[3:6,3:6]
egv=np.linalg.eig(np.transpose(Q))
i=np.where(np.isclose(egv[0],1))
mu=egv[1][:,i]
mu=mu/np.sum(mu)
print(mu)

# q3
x=4#Décalage de 1, on fait partir la chaîne de x+1
N=1000
plt.figure()
i=1
for n in [1,5,20]:
    Y=np.zeros(N)
    for j in range(1,N):
        Y[j]=exo3(x,n)[n]
    table=np.unique(Y,return_counts=True)
    plt.subplot(3,1,i)
    plt.bar(table[0]+1,table[1]/N,label='estimation de la loi')
    plt.vlines([4,5,6],0,mu,color='red',label='mesure invariante')
    plt.title('Estimation de la loi de X_n pour n= '+str(n))
    plt.plot()
    i=i+1
plt.show()

#q4
Q=P[1:3,1:3]
p=np.linalg.solve(np.identity(2)-Q,[1/4,0])
def exo3bis(x):
    X=x
    states=[j for j in range(6)]
    while X in [1,2] :
        X=npr.choice(states,p=P[X,:])
    return X
c=0.0
for j in range(1,N):
    c=c+(exo3bis(1)==0)
p01e=c/N
print('Probabilité estimée d\'absorption par 1 partant de 2: '+str(p01e))
print('Probabilité théorique d\'absorption par 1 partant de 2: '+str(p[0]))

c=0.0
for j in range(1,N):
    c=c+(exo3bis(2)==0)
p12e=c/N
print('Probabilité estimée d\'absorption par 1 partant de 3: '+str(p12e))
print('Probabilité théorique d\'absorption par 1 partant de 3: '+str(p[1]))

## Exo 4 Ehrenfest
#q1
def ehr(N,x0,T,Nsim):
    E=np.c_[(np.ones((Nsim,x0)),np.zeros((Nsim,N-x0)))]# ou np.concatenate(...,axis=1)
    X=np.zeros((Nsim,T+1))
    X[:,0]=np.sum(E,axis=1)
    for t in range(1,T+1):
        for j in range(0,Nsim):
            I=npr.randint(0,N)
            E[j,I]=1-E[j,I]
        X[:,t]=np.sum(E,axis=1)
    return(X)

# N=10
N=10
x0=0
T=1000
Nsim=2
X=ehr(N,x0,T,Nsim)
plt.figure()
plt.plot(X.T)
plt.title('N='+str(N)+' et T='+str(T))
plt.show()


# N=100
N=100
x0=0
T=1000
Nsim=2
X=ehr(N,x0,T,Nsim)
plt.figure()
plt.plot(X.T)
plt.title('N='+str(N)+' et T='+str(T))
plt.hlines([N/2-2*np.sqrt(N),N+2*np.sqrt(N)],0,T,linestyles='dotted')
plt.show()


# N=1000
N=1000
x0=0
T=100000
Nsim=2
X=ehr(N,x0,T,Nsim)
plt.figure()
plt.plot(X.T)
plt.hlines([N/2-2*np.sqrt(N),N/2+2*np.sqrt(N)],0,T,linestyles='dotted')
plt.title('N='+str(N)+' et T='+str(T))
plt.show()

#q2 Recherche de la mesure invariante par l'algèbre linéaire
N=6
P=np.zeros((N+1,N+1))
for i in range(0,N+1):
    if i>0: P[i,i-1]=i/N
    if i<N: P[i,i+1]=1-i/N
V=np.linalg.eig(P.T)
res=np.where(np.isclose(V[0],1))# on cherche l'indice correspondant à la valeur propre 1
i=res[0]
pi=V[1][:,i]
pi=pi.T/sum(pi)# On normalise pour avoir une mesure de proba
pitheo=stats.binom.pmf(range(0,N+1),N,1/2)#
print(np.sum(abs(pi-pitheo)))#Numériquement très proches

#q3 Convergence de la mesure empirique
N=6
x0=0
T=1000
Nsim=2
X=ehr(N,x0,T,Nsim)
T1=50
T2=100
T3=1000
X1=X[:,0:T1]
H=np.unique(X1,return_counts=True)
pi1=H[1]
val1=H[0]
pi1=pi1/sum(pi1)

X2=X[:,0:T2]
H=np.unique(X2,return_counts=True)
pi2=H[1]
val2=H[0]
pi2=pi2/sum(pi2)

X3=X[:,0:T3]
H=np.unique(X3,return_counts=True)
pi3=H[1]
val3=H[0]
pi3=pi3/sum(pi3)

plt.figure()
plt.bar(range(0,N+1),pitheo,label='Théorique',alpha=.5)
plt.scatter(val1,pi1,label='T='+str(T1))
plt.scatter(val2,pi2,label='T='+str(T2))
plt.scatter(val3,pi3,label='T='+str(T3))
plt.legend()
plt.show()

#q4
N=200
x0=0
T=1000
Nsim=500
X=ehr(N,x0,T,Nsim)
X1=X[:,T]
X1=sorted(X1)

plt.figure()
plt.step(X1,[j/Nsim for j in range(1,Nsim+1)],where='post')
plt.step(range(0,N+1),stats.binom.cdf(range(0,N+1),N,1/2),where='post')
plt.show()

#q5
def ehrabs(N,x0):
    E=np.c_[(np.ones((1,x0)),np.zeros((1,N-x0)))]# ou np.concatenate(...,axis=1)
    X=x0
    T=0
    while X!=N/2:
        T=T+1
        I=npr.randint(0,N)
        E[0,I]=1-E[0,I]
        X=np.sum(E,axis=1)
    return(T)
x0=0
Nsim=500
i=0
Nvec=[100*j for j in range(1,6)]
TT=np.zeros_like(Nvec)
for N in Nvec:
    T=np.zeros(Nsim)
    for j in range(0,Nsim):
        T[j]=ehrabs(N,x0)
    TT[i]=np.mean(T)
    i=i+1
plt.figure()
plt.plot(Nvec,TT)
plt.show()
# Semble quasiment linéaire, très différent du temps exponentiel en N pour revenir en 0

## Exo 5 Hardy-Weinberg
def HW(N,N0,T):
    E=np.c_[(np.ones((2,N0[0])),np.concatenate((np.ones((1,N0[1])),np.zeros((1,N0[1])))),np.zeros((2,N0[2])))]# ou np.concatenate(...,axis=1)
    E2=np.zeros_like(E)
    Nn=np.zeros((3,T+1))
    Nn[:,0]=N0
    for t in range(1,T+1):
        for j in range(0,N):
            I=npr.randint(0,N)
            J=npr.randint(0,N)
            I2=npr.choice([0,1])
            J2=npr.choice([0,1])
            E2[0,j]=E[I2,I]
            E2[1,j]=E[J2,J]
        E=E2
        Nn[:,t]=[np.sum(E[0,:]*E[1,:]),np.sum(E[0,:]*(1-E[1,:])+E[1,:]*(1-E[0,:])),np.sum((1-E[1,:])*(1-E[0,:]))]
    return(Nn)

#q1
T=10

N=1000
N0AA=500
N0Aa=200
N0aa=N-N0AA-N0Aa
N0=[N0AA,N0Aa,N0aa]
p0=N0AA/N
q0=N0Aa/N
r0=1-p0-q0

Nn=HW(N,N0,10)
p1=(p0+1/2*q0)**2
r1=(r0+1/2*q0)**2
q1=1-p1-r1
plt.figure()
plt.plot(range(0,T+1),Nn.T/N,label=['Nn(AA)','Nn(Aa)','Nn(aa)'])
plt.hlines([p1,q1,r1],0,T,label=['p1','q1','r1'],linestyles='dashed')
plt.title('Evolution des proportions de chaque génotype, N= '+str(N))
plt.legend()
plt.show()



N=10000
N0AA=5000
N0Aa=2000
N0aa=N-N0AA-N0Aa
N0=[N0AA,N0Aa,N0aa]
p0=N0AA/N
q0=N0Aa/N
r0=1-p0-q0

Nn=HW(N,N0,10)
p1=(p0+1/2*q0)**2
r1=(r0+1/2*q0)**2
q1=1-p1-r1
plt.figure()
plt.plot(range(0,T+1),Nn.T/N,label=['Nn(AA)','Nn(Aa)','Nn(aa)'])
plt.hlines([p1,q1,r1],0,T,label=['p1','q1','r1'],linestyles='dashed')
plt.title('Evolution des proportions de chaque génotype, N= '+str(N))
plt.legend()
plt.show()

# q2
T=10

N=1000
N0AA=100
N0Aa=100
N0aa=N-N0AA-N0Aa
N0=[N0AA,N0Aa,N0aa]
p0=N0AA/N
q0=N0Aa/N
r0=1-p0-q0

Nn=HW(N,N0,10)
p1=(p0+1/2*q0)**2
r1=(r0+1/2*q0)**2
q1=1-p1-r1
plt.figure()
plt.plot(range(0,T+1),Nn.T/N,label=['Nn(AA)','Nn(Aa)','Nn(aa)'])
plt.hlines([p1,q1,r1],0,T,label=['p1','q1','r1'],linestyles='dashed')
plt.title('Evolution des proportions de chaque génotype, N= '+str(N))
plt.legend()
plt.show()



N=10000
N0AA=1000
N0Aa=1000
N0aa=N-N0AA-N0Aa
N0=[N0AA,N0Aa,N0aa]
p0=N0AA/N
q0=N0Aa/N
r0=1-p0-q0

Nn=HW(N,N0,10)
p1=(p0+1/2*q0)**2
r1=(r0+1/2*q0)**2
q1=1-p1-r1
plt.figure()
plt.plot(range(0,T+1),Nn.T/N,label=['Nn(AA)','Nn(Aa)','Nn(aa)'])
plt.hlines([p1,q1,r1],0,T,label=['p1','q1','r1'],linestyles='dashed')
plt.title('Evolution des proportions de chaque génotype, N= '+str(N))
plt.legend()
plt.show()

## Exo 6 Jeu de Penney
#q1
# On remplace a par 0 et b par 1
def T(motif,Nsim):
    T=np.zeros(Nsim,dtype='int64')
    for i in range(0,Nsim):
        l=len(motif)
        X=npr.binomial(1,p=1/2,size=l)
        T[i]=l
        while np.any(X[[-j for j in range(1,l+1)]]!=motif):
            T[i]=T[i]+1
            X=np.append(X,npr.binomial(1,p=1/2))
    return T
Nsim=1000
Taa=T([0,0],Nsim)
Tab=T([0,1],Nsim)
TaaTable=np.unique(Taa,return_counts=True)
TabTable=np.unique(Tab,return_counts=True)

plt.figure()
plt.bar(TaaTable[0],TaaTable[1]/Nsim,alpha=0.5,label='Taa')# alpha pour la transparence
plt.bar(TabTable[0],TabTable[1]/Nsim,alpha=0.5,label='Tab')
plt.title('Estimation des lois de Taa et Tab')
plt.legend()
plt.show()

#q2
import sympy as sympy
x=sympy.var('x')
g0aa=x**2/4/(1-x/2-x**2/4)
gta=g0aa.series(x,0,max(Taa)+1)
gaatheo=[gta.coeff(x,n) for n in range(0,max(Taa)+1)]

g0ab=(x/2/(1-x/2))**2
gtb=g0ab.series(x,0,max(Tab)+1)
gabtheo=[gtb.coeff(x,n) for n in range(0,max(Tab)+1)]

plt.figure()
plt.bar(TaaTable[0],TaaTable[1]/Nsim,alpha=0.5,label='Distrib. estimée de Taa')# alpha pour la transparence
plt.bar(TabTable[0],TabTable[1]/Nsim,alpha=0.5,label='Distrib estimée de Tab')
plt.vlines(range(0,max(Taa)+1),0,gaatheo,label='Distrib. théorique de Taa')
plt.vlines([j+.1 for j in range(0,max(Tab)+1)],0,gabtheo,color='red',label='Distrib. théorique de Tab')
plt.title('Estimation des lois de Taa et Tab')
plt.legend()
plt.show()

f=1/(1-x/2)
print('Regardons les coefficients de f: ')
print('voici le développement de f en 0 à l''ordre 10:'+ str(f.series(x,0,10)))
f2=f.series(x,0,10)
print('voici le coefficient devant x^9: '+ str(f2.coeff(x,9)))